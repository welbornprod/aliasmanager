#!/bin/bash

# Opens Alias Manager
python /home/cj/workspace/eclipse/aliasmgr/aliasmgr.py $@
